Image from http://www.jfitz.com/cards/

From tha page:

These images were created using GIFCon, XnView and Paint Shop Pro.
Feel free to use for personal or professional purposes, subject to the following:
Additional Copyright information:
Larry Ewing <lewing@isc.tamu.edu> created Tux using GIMP.
Marshall Kirk McKusick <mckusick@mckusick.com> is the copyright holder and creator of the BSD Daemon image.
The "Windows" cards were originally designed by Susan Kare for Microsoft.
To the best of my knowledge, the images used in any "standard" French/British 52 card deck are public domain.
The top Jokers are derived from an image I found of a John Waddington design.
The bottom Jokers were created by me as quick placeholders for a design I never got around to implementing.
I guess it's possible that Microsoft could claim copyright on the Windows Ace of Spades.
If they did, I'd suggest filling in or changing the white pattern on the Spade.